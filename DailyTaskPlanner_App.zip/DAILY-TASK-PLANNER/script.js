const STORAGE_PREFIX = "dailyTaskPlanner.";
const MAX_LEN = 80;
const RANK = { High: 0, Medium: 1, Low: 2 };

const body = document.getElementById("body");
const sunWrapper = document.getElementById("sunWrapper");
const confetti = document.getElementById("confetti");
const taskInput = document.getElementById("taskInput");
const priority = document.getElementById("priority");
const taskTime = document.getElementById("taskTime");
const msg = document.getElementById("msg");
const taskList = document.getElementById("taskList");
const summaryText = document.getElementById("summaryText");
const barFill = document.getElementById("barFill");

const dayKey = todayKey();   // the day this planner page belongs to
let tasks = [];
let filter = "all";

init();

function init() {
  document.getElementById("todayDate").textContent = new Date().toLocaleDateString(
    "en-GB", { weekday: "long", day: "numeric", month: "long", year: "numeric" });
  buildConfetti();
  document.getElementById("addBtn").addEventListener("click", handleAddTask);
  taskInput.addEventListener("keydown", (e) => {
    if (e.key === "Enter") handleAddTask();
  });
  taskList.addEventListener("click", handleListClick);
  document.getElementById("filters").addEventListener("click", handleFilterClick);
  document.getElementById("clearBtn").addEventListener("click", clearCompleted);
  tasks = loadTasks();
  render();
}

function todayKey() {
  const d = new Date();
  const mm = String(d.getMonth() + 1).padStart(2, "0");
  const dd = String(d.getDate()).padStart(2, "0");
  return `${d.getFullYear()}-${mm}-${dd}`;
}

function loadTasks() {
  try {
    const raw = localStorage.getItem(STORAGE_PREFIX + dayKey);
    const list = raw ? JSON.parse(raw) : [];
    return Array.isArray(list) ? list.filter(isValidTask) : [];
  } catch (err) {
    console.error("Load error:", err);
    return [];
  }
}

function isValidTask(t) {
  return t && typeof t.id === "number" && typeof t.text === "string" &&
         t.text.length > 0 && t.text.length <= MAX_LEN && t.priority in RANK;
}

function saveTasks() {
  try {
    localStorage.setItem(STORAGE_PREFIX + dayKey, JSON.stringify(tasks));
    return true;
  } catch (err) {
    console.error("Save error:", err);
    return false;
  }
}

function showMessage(text, isError) {
  msg.textContent = text;
  msg.className = isError ? "msg error" : "msg ok";
}

function handleAddTask() {
  const text = taskInput.value.trim();
  showMessage("", false);
  if (!text) return showMessage("Please enter a task.", true);
  if (text.length > MAX_LEN) return showMessage(`Task is too long (max ${MAX_LEN} characters).`, true);
  if (tasks.some((t) => t.text.toLowerCase() === text.toLowerCase())) {
    return showMessage("This task is already in today's list.", true);
  }
  tasks.push({ id: Date.now() + tasks.length, text, priority: priority.value,
               time: taskTime.value, done: false });
  tasks.sort(compareTasks);
  taskInput.value = "";
  taskTime.value = "";
  taskInput.focus();
  const saved = saveTasks();
  render();
  if (saved) showMessage("Task added.", false);
  else showMessage("Task added, but it could not be saved in this browser.", true);
}

function compareTasks(a, b) {
  const ta = a.time || "99:99", tb = b.time || "99:99";
  return ta.localeCompare(tb) || RANK[a.priority] - RANK[b.priority] || a.id - b.id;
}

function handleListClick(e) {
  const item = e.target.closest("li");
  if (!item) return;
  const id = Number(item.dataset.id);
  if (e.target.matches("input[type=checkbox]")) {
    const t = tasks.find((x) => x.id === id);
    if (t) t.done = e.target.checked;
  } else if (e.target.matches("button.del")) {
    tasks = tasks.filter((x) => x.id !== id);
  } else return;
  saveTasks();
  render();
}

function handleFilterClick(e) {
  const btn = e.target.closest("button[data-filter]");
  if (!btn) return;
  filter = btn.dataset.filter;
  document.querySelectorAll(".filter").forEach((b) => b.classList.toggle("active", b === btn));
  render();
}

function clearCompleted() {
  tasks = tasks.filter((t) => !t.done);
  saveTasks();
  render();
}

function render() {
  taskList.textContent = "";
  const shown = tasks.filter((t) =>
    filter === "all" || (filter === "done" ? t.done : !t.done));
  if (shown.length === 0) {
    const li = document.createElement("li");
    li.className = "empty";
    li.textContent = tasks.length ? "No tasks in this view." : "No tasks yet. Add your first task.";
    taskList.appendChild(li);
  }
  shown.forEach((t) => taskList.appendChild(buildItem(t)));
  const done = tasks.filter((t) => t.done).length;
  const pct = tasks.length ? Math.floor((done / tasks.length) * 100) : 0;
  summaryText.textContent = `${done} of ${tasks.length} tasks done`;
  barFill.style.width = pct + "%";
  updateTheme(pct, tasks.length);
}

function buildItem(t) {
  const li = document.createElement("li");
  li.dataset.id = t.id;
  li.className = "task" + (t.done ? " done" : "");
  const box = document.createElement("input");
  box.type = "checkbox";
  box.checked = t.done;
  box.setAttribute("aria-label", "Mark done: " + t.text);
  const label = document.createElement("span");
  label.className = "task-text";
  label.textContent = t.text;
  const badge = document.createElement("span");
  badge.className = "badge " + t.priority.toLowerCase();
  badge.textContent = t.priority;
  const time = document.createElement("span");
  time.className = "task-time";
  time.textContent = t.time || "";
  const del = document.createElement("button");
  del.className = "del";
  del.textContent = "\u2715";
  del.setAttribute("aria-label", "Delete task: " + t.text);
  li.append(box, label, time, badge, del);
  return li;
}

function updateTheme(pct, total) {
  body.classList.remove("theme-empty", "theme-start", "theme-half", "theme-done");
  if (total === 0) body.classList.add("theme-empty");
  else if (pct === 100) body.classList.add("theme-done");
  else if (pct >= 50) body.classList.add("theme-half");
  else body.classList.add("theme-start");
  body.style.setProperty("--progress", pct / 100);
}

function buildConfetti() {
  const colors = ["#ffd54f", "#ef5350", "#42a5f5", "#ab47bc", "#ffffff"];
  for (let i = 0; i < 16; i++) {
    const s = document.createElement("span");
    s.style.left = (i * 6.4 + 2) + "%";
    s.style.background = colors[i % colors.length];
    s.style.animationDelay = (i % 8) * 0.35 + "s";
    confetti.appendChild(s);
  }
}
